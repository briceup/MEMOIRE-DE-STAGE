<?php
/**
 * CinetPay Payment Gateway : standard payment class.
 */
class WC_Gateway_CinetpayStd extends WC_Gateway_Cinetpay {

	public function __construct() {
		$this->id = 'cinetpaystd';
		$this->icon = apply_filters('woocommerce_cinetpaystd_icon', WC_CINETPAY_PLUGIN_URL . '/assets/images/cinetpay.png');
		$this->has_fields = false;
		$this->method_title = 'CinetPay - ' . __('Paiement', 'cinetpay');

		// init CinetPay common vars
		$this->cinetpay_init();

		// load the form fields
		$this->init_form_fields();
		// load the module settings
		$this->init_settings();

		// define user set variables
		$this->title = $this->settings['title'];
		$this->description = $this->settings['description'];
		$this->debug = (isset($this->settings['debug']) && $this->settings['debug'] == 'yes') ? true : false;

		// reset CinetPay standard payment admin form action
		add_action( 'woocommerce_settings_start', array($this, 'cinetpay_reset_admin_options'));

		// update CinetPay standard payment admin form action
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

		// generate CinetPay standard payment form action
		add_action('woocommerce_receipt_' . $this->id, array($this, 'cinetpay_generate_form'));

		// return from payment platform action
		add_action('woocommerce_api_wc_gateway_cinetpay', array($this, 'cinetpay_notify_response'));
		// insert into database
		add_action('woocommerce_add_order_item_meta',array($this, 'wdm_add_values_to_order_item_meta'),10,2);

		//add_action( 'woocommerce_available_payment_gateways', 'desactivate' );
	}

	/**
	 * Get icon function.
	 *
	 * @access public
	 * @return string
	 */
	public function get_icon() {
		global $woocommerce;

		$icon = '';

		if($this->icon) {
			$icon = '<img style="width: 85px;" src="';
			$icon .= class_exists('WC_HTTPS') ? WC_HTTPS::force_https_url($this->icon) : $woocommerce->force_ssl($this->icon);
			$icon .= '" alt="' . $this->title . '" />';
		}

		return apply_filters('woocommerce_gateway_icon', $icon, $this->id );
	}

	/**
	 * Initialise Gateway Settings Form Fields.
	 */
	public function init_form_fields() {
		global $woocommerce;

		// load common form fields to concat them with sub-module settings
		parent::init_form_fields();
		foreach ($this->form_fields as $k => $v) {
			$this->cinetpay_common_fields[$k] = $v;
		}

		$this->form_fields = array(
				// CMS config params
				'module_settings' => array(
						'title' => __('PARAMETRES DE BASE', 'cinetpay'),
						'type' => 'title'
				),
				'enabled' => array(
						'title' => __('Activation', 'cinetpay'),
						'label' => __('Activer / désactiver', 'cinetpay'),
						'type' => 'checkbox',
						'default' => 'yes', 
						'description' => __('Activer / désactiver le paiement CinetPay.', 'cinetpay')
				), 
				'title' => array(
						'title' => __('Titre', 'cinetpay'),
						'type' => 'text',
						'description' => __('Le titre que l\'utilisateur voit lors de la commande.', 'cinetpay'),
						'default' => 'Paiement avec CinetPay'
				),
				'description' => array(
						'title' => __( 'Description', 'cinetpay' ),
						'type' => 'textarea',
						'description' => __( 'la description que l\'utilisateur voit lors de la commande.', 'cinetpay' ),
						'default' => 'Vous allez être redirigé(e) vers la page de paiement après confirmation de la commande.',
				),
		);
	}

	/**
	 * Override init_settings methode to retrieve CinetPay common settings.
	 */
	public function init_settings() {
		parent::init_settings();

		$common_settings = get_option('woocommerce_cinetpay_settings', null );

		// if there are no settings defined, load defaults
		if ((!$common_settings || !is_array($common_settings)) && isset($this->cinetpay_common_fields) && is_array($this->cinetpay_common_fields)) {
			foreach ($this->cinetpay_common_fields as $k => $v) {
				$this->settings[$k] = isset($v['default']) ? $v['default'] : '';
			}
		} else {
			foreach ($common_settings as $k => $v) {
				$this->settings[$k] =  $v ;
			}
		}
		//si la devise de la boutique n'est pas supporté par cinetpay, on desactive le moyen de paiement
		$support = $this->CurrencySupportCinetpay(get_woocommerce_currency());
		$conversion = $this->get_option('conversion');
		//
		if($conversion != 'yes' && $support == null ){
			$this->enabled = 'no';
		}
	}

	/**
	 * Check if this gateway is enabled and available for the current cart.
	 */
	public function is_available() {
		global $woocommerce;

		if(!$this->is_supported_currency()) {
			return false;
		}

		return parent::is_available();
	}

	//enregistrer les données en base

	public function wdm_add_values_to_order_item_meta($item_id, $values)
		{
				global $woocommerce,$wpdb;
				$order = new WC_Order($order_id);
				
				/* A retirer
				wc_update_order_item_meta($item_id,'trans_id','test-'.$order->id); */  
				
		}
	

	/**
	 * Process the payment and return the result.
	 **/
	public function process_payment($order_id) {
		global $woocommerce;

		$order = new WC_Order($order_id);

		if(version_compare($woocommerce->version, '2.1.0', '<')) {
			$pay_url = add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay'))));
		} else {
			$pay_url = $order->get_checkout_payment_url(true);
		}

		return array(
				'result' 	=> 'success',
				'redirect'	=> $pay_url
		);
	}
	/**
	 * Order review and payment form page.
	 **/
	public function cinetpay_generate_form($order_id) {
        global $woocommerce, $wpdb;
        $order = new WC_Order($order_id);
		
		$order_data = $order->get_data();

        $id_transaction =  Cinetpay::generateTransId();

		$conversion = $this->get_option('conversion');// Recupère La configuration concernant la conversion

		//PRODUCTION URL
		$notify_url = WC()->api_request_url('WC_Gateway_Cinetpay');
		$return_url = $order->get_checkout_order_received_url();
		$cancel_url = get_permalink(woocommerce_get_page_id('shop'));

		//Recherche des produits selectionné afin d'affecter à la description
		foreach( WC()->cart->get_cart() as $cart_item ) {
			$product_name[] = $cart_item['data']->get_name()." .";
			
		}
		$list_produit = "Paiement de ".implode(" ",$product_name);

		if($conversion == 'yes')//Si l'option Conversion est coché, on verifie que le pays du payeur est supporté par CinetPay
		{
			/* Utilisation de la devise pour la concatener au pays. 
             * Utile pour les pays qui utilise plusieurs devise comme RDCongo(22-03-2022)*/
		  $currency_customer = $this->checkCurrency($order->get_billing_country(),get_woocommerce_currency());

		  $alternative_currency = get_woocommerce_currency(); // on recupère la devise de la boutique pour l'afficher
		  
		  $this->log("Alternative".$alternative_currency);
		  if($currency_customer == null) 
		  {
			/* Le client utilisera la devise de la boutique 
			 * si la devise de son pays n'est pas supporté par CinetPay et 
			 * il ne pourra payer qu'avec Carte bancaire(05-02-2022)*/
			$currency_customer  = $alternative_currency;
			$montant_a_payer = $order->total;
			$channels = "CREDIT_CARD";
			
		  //	echo("Votre position geographique ne vous permet pas d'effectuer ce paiement");  
		  }
		  else{
			  //on effectue une conversion de la devise de la boutique dans celle du client
			$montant_a_payer = $this->convertPriceFull($order->total, strtoupper($order->currency), $currency_customer);
		  }
		}
		
		else //On verifie que la devise de configuration est supporté par CinetPay 
		{	
		   $currency_customer = $this->CurrencySupportCinetpay($order->currency); 
		   $alternative_currency = null;
		   if($currency_customer == null)
		   {
			echo("Votre position geographique ne vous permet pas d'effectuer ce paiement"); 
		   }
		   else {
			   $montant_a_payer = $this->convertPriceFull($order->total, strtoupper($order->currency), $currency_customer);
		   }
		   
		}
        
		$this->log($order->total." ". $order->currency. 'Converti en :' . $montant_a_payer . " " . $currency_customer."order-data:" .$order_data['currency']);

		// on verifie que le montant est un multiple de 5 en s'assurant d'abord de la devise de conversion, sinon on le multiple au multiple de 5.
		$montant_a_payer = $this->multipleFive($currency_customer,$montant_a_payer);

        $order_array = [
            'id'=>$order->id,
            'status'=>$order->status,
            'currency'=>$order->currency,
            'order_key'=>$order->order_key,
            'email'=>$order->email,
            'amount_to_cinetpay_currency' => $montant_a_payer
        ];
        $order_infos = serialize($order_array);
		//recuperation du prefixe number pour le pays
		$calling_code = WC()->countries->get_country_calling_code($order->get_billing_country());
        $calling_code = is_array( $calling_code ) ? $calling_code[0] : $calling_code;
        try{
			// create for newGuichet
			$formData = array(
				"transaction_id" => $id_transaction,
				"amount"=> $montant_a_payer,
				"currency"=> $currency_customer,
				"customer_surname"=> $order_data['billing']['first_name'],
				"customer_name"=> $order_data['billing']['last_name'],
				"description"=> $list_produit,
				"notify_url" => $notify_url,
				"return_url" => $return_url,
				"metadata" => $order_infos,
				"channels" => $channels ?: "ALL",
				"alternative_currency" => $alternative_currency,
				//pour afficher le paiement par carte de credit
				"customer_email" => $order_data['billing']['email'],
				"customer_phone_number" => $order_data['billing']['phone'],
				"customer_address" => $order_data['billing']['address_1'],
				"customer_city" => $order_data['billing']['city'],
				"customer_country" => $order_data['billing']['country'],
				"customer_state" => $order_data['billing']['state'],
				"customer_zip_code" => $order_data['billing']['postcode'],
			);
            $apiKey = $this->get_option('apikey');

            $site_id = $this->get_option('site_id');

            $version = "V2";

            $formName = $this->id . '_payment_form';

            $btnType = 1;
            $btnSize = 'large';
            $CinetPay = new CinetPay($site_id, $apiKey, $version);
			
			if($montant_a_payer != null)
			{
			 $result = $CinetPay->generatePaymentLink($formData);
			}
			// Log les paramètres soumis
            $this->log(print_r($formData,true));

			//redirection url de paiement
		    if($result['code']=='201')
			{
				//Enregistrer les infos dans la table
				$table_name = $wpdb->prefix . "cinetpay";

				$wpdb->insert( $table_name, array( 
					'order_id' => $order->id,
					'transaction_id' => $id_transaction, 
					'token' => $result['data']['payment_token'], 
					'payment_url'=> $result['data']['payment_url'], 
					'amount' => $montant_a_payer ) );

				$btn = "<a style='text-decoration: none;' class='cinetpay-button larger' href= " . $result['data']['payment_url'] . " > Payer </a>";
        		print $btn;
			}
            echo  '<br><a style="display: inline-block; margin-top: 1rem" class="button cancel" class="button cancel" href="' . esc_url($order->get_cancel_order_url() ) . '">'.__('Annuler la commande &amp; Restaurer le panier', 'cinetpay') . '</a>';
        }catch (Exception $e){
            echo $e->getMessage();
        }
	}



}