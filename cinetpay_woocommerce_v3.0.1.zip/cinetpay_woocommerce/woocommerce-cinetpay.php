<?php
/**
 * CinetPay V2-Payment Module version 3.0.0 .
 *
 * Copyright (C) 2021 CinetPay and contributors
 * Support contact : support@cinetpay.eu
 * Author link : http://cinetpay.com/
 * Contributors : COLLE JEREMIE
 *
 * @category  payment
 * @package   cinetpay
 * @author    CinetPay <support@cinetpay.com>
 * @copyright 2014-2021 CinetPay and contributors
 * @license   http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  GNU General Public License (GPL v2)
 * @version   3.0.1
*/

/*
Plugin Name: CinetPay Paiement sur WooCommerce
Plugin URI: http://www.cinetpay.com
Description: Ce plugin WordPress relie votre boutique WooCommerce à la plateforme de paiement CinePay.
Author: CinetPay
Contributors: COLLE JEREMIE
Version: 3.0.1
Author URI: http://www.cinetpay.com
License: GPLv2 or later
Text Domain: cinetpay
Domain Path: /languages/
*/

if (!defined('ABSPATH')) exit; // exit if accessed directly

define('WC_CINETPAY_PLUGIN_URL', plugin_dir_url(__FILE__));

/* Check requirements */
function woocommerce_cinetpay_activation() {
	if (!is_plugin_active('woocommerce/woocommerce.php')) {
		deactivate_plugins(plugin_basename(__FILE__)); // deactivate ourself

		// charge les fichiers de traduction
		load_textdomain('cinetpay', WP_PLUGIN_DIR . '/woocommerce-cinetpay/languages/cinetpay-' . get_locale() . '.mo');

		$message = sprintf(__('Desole ! Pour utiliser le plugin woocommerce : %s, Il faut installer et activer le plugin WooCommerce.', 'cinetpay'), 'CinetPay');
		wp_die($message, 'WooCommerce CinetPay Payment', array('back_link' => true));
	}
}

register_activation_hook(__FILE__, 'woocommerce_cinetpay_activation');

/* inclus gateway classes */
function woocommerce_cinetpay_init() {
	// charge les fichiers de traduction
	load_textdomain('cinetpay', WP_PLUGIN_DIR . '/woocommerce-cinetpay/languages/cinetpay-' . get_locale() . '.mo');

	if (!class_exists('WC_Gateway_Cinetpay')) {
		require_once 'class-wc-gateway-cinetpay.php';
	}
	if (!class_exists('WC_Gateway_CinetpayStd')) {
		require_once 'class-wc-gateway-cinetpaystd.php';
	}
	require_once 'new-guichet.php';
}

add_action('woocommerce_init', 'woocommerce_cinetpay_init');


/* ajoutes les methodes CinetPay a woocommerce */
function woocommerce_cinetpay_add_method($methods) {
	$methods[] = 'WC_Gateway_Cinetpay';
	$methods[] = 'WC_Gateway_CinetpayStd';
	return $methods;
}
add_filter('woocommerce_payment_gateways', 'woocommerce_cinetpay_add_method');

/* Add a link from plugin list to parameters */
function woocommerce_cinetpay_add_link($links, $file) {
	global $woocommerce;

	// consider payment gateways tab change
	$base_url	= 'admin.php?page=wc-settings&tab=checkout&section=';
	$url_gen	= $base_url . 'wc_gateway_cinetpay';
	$url_std	= $base_url . 'wc_gateway_cinetpaystd';

	// backward compatibility
	if(version_compare($woocommerce->version, '2.1.0', '<')) {
		$base_url	= 'admin.php?page=woocommerce_settings&tab=payment_gateways&section=';
		$url_gen	= $base_url . 'WC_Gateway_Cinetpay';
		$url_std	= $base_url . 'WC_Gateway_CinetpayStd';

	}

	$links[] = '<a href="' . admin_url($url_gen) . '">' . __('Configuration g&eacute;n&eacute;rale', 'cinetpay') .'</a>';

	$links[] = '<a href="' . admin_url($url_std) . '">' . __('CinetPay paiement', 'cinetpay') .'</a>';

	return $links;
}
add_filter('plugin_action_links_'.plugin_basename(__FILE__), 'woocommerce_cinetpay_add_link',  10, 2);

/* Retrieve blog_id from post when this is a CinetPay IPN URL call */
if(is_multisite() && key_exists('vads_hash', $_POST) && $_POST['vads_hash']
		&& key_exists('vads_order_info2', $_POST) && $_POST['vads_order_info2']) {

	global $wpdb, $current_blog, $current_site;

	$blog = substr($_POST['vads_order_info2'], strlen('blog_id='));
	switch_to_blog((int)$blog);

	// set current_blog global var
	$current_blog = $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM $wpdb->blogs WHERE blog_id = %s", $blog)
	);

	// set current_site global var
	$current_site = wp_get_network($current_blog->site_id);
	$current_site->blog_id = $wpdb->get_var(
			$wpdb->prepare(
					"SELECT blog_id FROM $wpdb->blogs WHERE domain = %s AND path = %s",
					$current_site->domain, $current_site->path
			)
	);
	$current_site->site_name = get_site_option('site_name');
	if (!$current_site->site_name) {
		$current_site->site_name = ucfirst($current_site->domain);
	}
}
// create new table
function table_create()
{
global $wpdb;
$table_name = $wpdb->prefix . "cinetpay"; 
$charset_collate = $wpdb->get_charset_collate();
 $sql = "CREATE TABLE IF NOT EXISTS $table_name (
  id mediumint(9) NOT NULL AUTO_INCREMENT,
  order_id int (11) NOT NULL,
  transaction_id tinytext NOT NULL,
  token tinytext NOT NULL,
  payment_url tinytext NOT NULL,
  amount int (11) NOT NULL,
  created_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, 
  PRIMARY KEY  (id)
) $charset_collate";
require_once( ABSPATH .'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
}
register_activation_hook( __FILE__, 'table_create' );

//uninstall plugin

function cinetpay_remove_database()
{
	global $wpdb;
	$table_name = $wpdb->prefix . "cinetpay"; 

	$sql = "DROP TABLE IF EXISTS $table_name";
	$wpdb->query($sql);
}
register_uninstall_hook(__FILE__,'cinetpay_remove_database');


