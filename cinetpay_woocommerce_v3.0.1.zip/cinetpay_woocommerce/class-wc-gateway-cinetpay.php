<?php
/**
 * CinetPay Payment Gateway : common class.
 */
class WC_Gateway_Cinetpay extends WC_Payment_Gateway {

	public function __construct() {
		$this->id = 'cinetpay';
		$this->has_fields = false;
		$this->method_title = 'CinetPay - ' . __('Configuration G&eacute;n&eacute;rale', 'cinetpay');

		// init CinetPay common vars
		$this->cinetpay_init();
        
		// load the form fields
		$this->init_form_fields();

		// load the module settings
		$this->init_settings();

		$this->title = __('Configuration G&eacute;n&eacute;rale', 'cinetpay');
		$this->enabled = false;
		$this->debug = (isset($this->settings['debug']) && $this->settings['debug'] == 'yes') ? true : false;

		// reset cinetpay common admin form action
		add_action('woocommerce_settings_start', array($this, 'cinetpay_reset_admin_options'));
  
		// update cinetpay admin form action
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

		// return from payment platform action
		add_action('woocommerce_api_wc_gateway_cinetpay', array($this, 'cinetpay_notify_response'));

	}

	protected function cinetpay_init() {
		global $woocommerce;

		$this->logger = new WC_Logger();

		// init CinetPay API
		$this->admin_section = 'wc_gateway_' . $this->id;
		$this->admin_tab = 'checkout';
		$this->admin_page = 'wc-settings';

		// backward compatibility
		if(version_compare($woocommerce->version, '2.1.0', '<')) {
			$this->admin_section = get_class($this);
			$this->admin_tab = 'payment_gateways';
			$this->admin_page = 'woocommerce_settings';
		}

		// admin settings page URL
		$this->admin_link = add_query_arg('section', $this->admin_section,
				add_query_arg('tab', $this->admin_tab,
						add_query_arg('page', $this->admin_page, admin_url('admin.php'))));

		// reset admin settings URL
		$this->reset_admin_link = $this->admin_link;
		$this->reset_admin_link = add_query_arg('noheader', 'true', add_query_arg('reset', 'true', $this->reset_admin_link));
		$this->reset_admin_link = wp_nonce_url($this->reset_admin_link, $this->admin_page);
	}

	/**
	 * Admin Panel Options.
	 */
	public function admin_options() {
		if (!$this->is_supported_currency()) {
			echo '<div class="inline error"><p><strong>' . __('Plateforme d&eacute;sactiv&eacute;e', 'cinetpay') . ': ' . sprintf(__( '%s ne supporte pas votre devise actuelle.', 'cinetpay'), 'CinetPay') . '</strong></p></div>';
		}

		if (get_transient($this->id . '_settings_reset')) {
			delete_transient($this->id . '_settings_reset');

			echo '<div class="inline updated"><p><strong>' . sprintf(__( 'Ton %s module de configuration a &eacute;t&eacute; reinitialis&eacute;e avec succ&egrave;s.', 'cinetpay'), 'CinetPay') . '</strong></p></div>';
		}
		?>

    <br />
    <h3>CinetPay</h3>
    <p>
        <?php echo sprintf(__('Le module fonctionne en envoyant les utilisateurs sur %s en vu de choisir leur moyen de paiement et d\'entrer leur information de paiement.', 'cinetpay'), 'CinetPay'); ?>
    </p>

    <table>
        <?php $this->generate_settings_html(); // generate the HTML For the settings form ?>
    </table>

    <a href="<?php echo $this->reset_admin_link; ?>">
        <?php _e('Reinitialiser la configuration', 'cinetpay');?>
    </a>

    <?php
	}


	public function cinetpay_reset_admin_options() {
		// if not reset action do nothing
		if(!isset($_GET['reset'])) {
			return;
		}

		// check if correct link
		if($this->admin_section != $_GET['section']) {
			return;
		}

		delete_option('woocommerce_' . $this->id . '_settings');

		// transcient flag to display reset message
		set_transient($this->id . '_settings_reset', 'true');

		wp_redirect($this->admin_link);
		die();
	}

	protected function get_supported_languages($all = false) {
		$langs = array();
		if($all) {
			$langs[''] = __('All', 'cinetpay');
		}

		foreach (CinetpayApi::getSupportedLanguages() as $code => $label) {
			$langs[$code] = __($label, 'cinetpay');
		}
		return $langs;
	}

	protected function get_supported_card_types() {
		$cards = array_merge(
				array('' => __('All', 'cinetpay')),
				CinetpayApi::getSupportedCardTypes()
		);

		return $cards;
	}

	/**
	 * Initialise Gateway Settings Form Fields
	 */
	public function init_form_fields() {
		global $woocommerce;

		if(function_exists('wc_get_log_file_path')) {
			$log_folder = dirname(wc_get_log_file_path('cinetpay')) . '/';
		} else {
			$log_folder = $woocommerce->plugin_path() . '/logs/';
		}
		$log_folder = str_replace('\\', '/', $log_folder);

		// get relative path
		$base_dir = str_replace('\\', '/', ABSPATH);
		if(strpos($log_folder, $base_dir) === 0) {
			$log_folder = str_replace($base_dir, '', $log_folder);
		} else {
			$base_dir = str_replace('\\', '/', dirname(ABSPATH));
			$log_folder = str_replace($base_dir, '..', $log_folder);
		}
		$this->form_fields = array(

				'base_settings' => array(
						'title' => __( 'REGLAGES DE BASE', 'cinetpay' ),
						'type' => 'title'
				),
				'debug' => array(
						'title' => __( 'Logs', 'cinetpay' ),
						'label' => __('Activer / désactiver', 'cinetpay'),
						'type' => 'checkbox',
						'default' => 'yes',
						'description' => sprintf(__('Activer / désactiver les logs. Le fichier log est situé dans <code>%s</code>.', 'cinetpay'), $log_folder),
				),

				// payment platform access params
				'payment_platform_access' => array(
						'title' => __('ACCESS PLATEFORME', 'cinetpay'),
						'type' => 'title'
				),
				'site_id' => array(
						'title' => __('Site ID', 'cinetpay'),
						'type' => 'text',
						'default' => '485179',
						'description' => sprintf(__( 'l\'identifiant donn&eacute; par %s.', 'cinetpay'), 'CinetPay'),
				),
				'apikey' => array(
						'title' => ('Api Key'),
						'type' => 'text',
						'default' => '39955468c7a8c0cef1.68322505',
						'description' => sprintf(__( 'l\'Apikey fournit par %s (disponible dans le back office de %s Back Office).', 'cinetpay'), 'CinetPay', 'CinetPay'),
				),
                'conversion' => array(
                    'title' => __('Devises de Paiement', 'cinetpay'),
                    'label' => __('CinetPay n’est autorisé à encaisser qu’en devise locale.'),
                    'type' => 'checkbox',
                    'description' => __('En acceptant la conversion proposée par CinetPay, vous acceptez une conversion à titre indicatif'),
                ),
                array(
                    'title' => __('NOTE IMPORTANTE:'),
                    'type' => 'text',
                    'description' =>'<span style="color: red;font-weight: bold; ">Si le montant n’est pas un multiple de cinq(5), le module arrondira le montant au multiple de cinq(5) supérieur .</span>',
                    'css' => 'display: none;'
                )
                /* 'url_check' => array(
                    'title' => __('URL de notification'),
                    'type' => 'text',
                    'description' =>  WC()->api_request_url('WC_Gateway_Cinetpay') . '<br />',
                    'css' => 'display: none;'
                ), */
                
		);
        
        //on verifie que Cinetpay supporte cette devise
        $support = $this->CurrencySupportCinetpay(get_woocommerce_currency());
        //condition sur la conversion check paiement
        $conversion = $this->get_option('conversion');

        if($conversion != 'yes' && $support == null )
        {
            //on ajoute si cela existe
            $vari = array('title' => __('ATTENTION:'),'type' => 'text','description' =>'<span style="color: red;font-weight: bold; font-size: 20px;">Cette action est nécessaire pour effectuer le paiement. En cas de refus, vous ne pourrais pas recevoir de paiement en devise.</span><br>CinetPay se dédouane de tous frais supplémentaires applicables à cette transaction','css' => 'display: none;');
            array_push($this->form_fields,$vari);

            
        } 
        
        
	}

	public function generate_label_html( $key, $data ) {
		$defaults = array(
				'title'             => '',
				'class'             => '',
				'css'               => '',
				'placeholder'       => '',
				'type'              => 'label',
				'description'       => ''
		);

		$data = wp_parse_args( $data, $defaults );

		ob_start();
		if ($data != null)
		?>
        <tr valign="top">
            <td class="forminp" colspan="2">
                <fieldset>
                    <label class="<?php echo esc_attr( $data['class'] ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>">
                        <?php echo wp_kses_post( $data['title'] ); ?>
                    </label>
                    <p class="description">
                        <?php echo wp_kses_post($data['description']); ?>
                    </p>
                </fieldset>
            </td>
        </tr>
        <?php
		return ob_get_clean();
	}

	/**
	 * Check if this gateway is available for the current currency.
	 */
	protected function is_supported_currency() {

		return true;
	}

	/**
	 * Check for CinetPay notify Response.
	 **/
	public function cinetpay_notify_response() {
        @ob_clean();
        $response = (array)stripslashes_deep($_REQUEST);
        // Initialisation de CinetPay et Identification du paiement
        $id_transaction = $response['cpm_trans_id'];
        //Veuillez entrer votre apiKey et site ID
        $apiKey = $this->get_option('apikey');

        $site_id = $this->get_option('site_id');

        $version = "V2";
        $CinetPay = new CinetPay($site_id, $apiKey, $version,[]);
        //Prise des données chez CinetPay correspondant à ce paiement
        $CinetPay->setTransId($id_transaction)->getPayStatus();

        header('HTTP/1.1 200 OK');
        $this->cinetpay_manage_notify_response($CinetPay,$id_transaction);

	}

    /**
     * Valid payment process : update order, send mail, ...
     * @param $CinetPay
     */
	public function cinetpay_manage_notify_response($CinetPay,$id_transaction) {
        global $woocommerce, $wpdb;
        $this->clear_notices();
            try {
                $result = $CinetPay->chk_payment;

                $message = $result['message'];
                $code = $result['code'];
                $amount = $result['data']['amount'];
                $currency = $result['data']['currency'];
                //commentaire dans la note
                $commentaire = '<br>identifiant transaction chez CinetPay: ' .$id_transaction.'<br>montant:'.$amount." ".$currency;

                $this->log('transaction'.$id_transaction.'montant'.$amount);
                //Rechercher et recuperer la commande qui correpond  à cette transaction
                $order_id = $wpdb->get_var("SELECT order_id FROM {$wpdb->prefix}cinetpay WHERE transaction_id ='".$id_transaction."' ");

                $error_url = $woocommerce->cart->get_checkout_url();// url en cas d'erreur

                if (!isset($order_id) || $code == '404') {
                    $this->log('Error: la transaction (' . $id_transaction . ') concernant la commande ' .$order_id. ' n a pas ete trouve ou la cle ne correspond pas l id appele .');
                    wp_die("Erreur :la transaction ".$id_transaction." concernant la commande ' .$order_id. ' n'a pas ete trouv&eacute. Cliquer <a href='".$error."'>ici</a> pour revenir sur votre panier");
                    die();
                }
                $order = new WC_Order((int) $order_id);

                //$currency_customer = $this->getBillingCurrency($order->get_billing_country());
                if(version_compare($woocommerce->version, '2.1.0', '<')) {
                    $error_url = $order->get_cancel_order_url();
                }

                // get actual transaction's status in your db
                if($this->is_new_order($order, $id_transaction)){
                    update_post_meta((int) $order->id, 'Transaction ID', $id_transaction);


                    if($code == '00' && $message == 'SUCCES'){
                        $this->log('Paiement valide, On enregistre la commande #' . $order->id);
                        // payment completed
                        $note = 'Paiement reussi'.$commentaire;
                        $order->add_order_note($note);
                        //$order->update_status('completed');
                        $order->payment_complete();
                        $this->add_notice("Votre paiement a &eacute;t&eacute valid&eacute; avec succ&eagrave;");
                        //wp_redirect($this->get_return_url($order));
                        die();
                    }elseif ($code == '623') {
                        $note = 'En attente de validation'.$commentaire;
                        $order->add_order_note($note);
                        //$order->update_status('on-hold');
                        $this->log('Le paiement est en attente de validation du client');
                        $this->add_notice("Vous devez valider votre paiement avant qu'il soit pris en compte", "error");
                        //wp_redirect($this->get_return_url($order));
                        die();
                    }elseif ($code == '602') {
                        $note = 'Compte client insuffisant'.$commentaire;
                        $order->add_order_note($note);
                        $order->update_status('failed');
                        $this->log('Paiement echou&eacute; car le compte du client est insuffisant');
                        $this->add_notice('Le paiement a echou&eacute; car votre compte est insuffisant', 'error');
                    }elseif ($code == '604') {
                        $note = 'Le code OTP est erron&eacute;'.$commentaire;
                        $order->add_order_note($note);
                        $order->update_status('failed');
                        $this->log('Paiement echou&eacute; car Le code OTP est erron&eacute;');
                        $this->add_notice('Le paiement a echou&eacute; car le code OTP est erron&eacute;', 'error');
                        //wp_redirect($error_url);
                        die();
                    }elseif ($code == '627') {
                        $note = 'Annulation volontairement de la transaction'.$commentaire;
                        $order->add_order_note($note);
                        $order->cancel_order();
                        $this->log('Paiement echou&eacute; car Annulation volontairement la transaction');
                        $this->add_notice('Le paiement a echou&eacute; car vous avez annulez le paiement', 'error');
                        //wp_redirect($error_url);
                        die();
                    }elseif ($message == 'PAYMENT_FAILED') {
                        $note = 'Le paiement a echou&eacute'.$commentaire;
                        $order->add_order_note($note);
                        $order->update_status('failed');
                        $this->log('Paiement echou&eacute');
                        $this->add_notice('Le paiement a echou&eacute; car une erreur est survenue', 'error');
                    }
                }else {
                    $this->log('La commande #' . $order->id. 'a deja eté traité, on retraitera la commande en cas de changement de statut' );
                    wp_die($order->status,$message);
                    if($order->status === 'completed' || $order->status === 'processing') {
                        $this->log('Paiement complet&eacute; reconfirm&eacute;.');
                        //wp_redirect($this->get_return_url($order));
                        die();
                    }elseif($order->status === 'on-hold' || $order->status === 'failed' || $order->status === 'cancelled') {
                        if($code == '00' && $message == 'SUCCES') {
                            $this->log('Paiement valide, On traite la commande #' . $order->id.' qui avait le status '.$order->status);
                            $note = 'Paiement valid&eacute'.$commentaire;
                            $order->add_order_note($note);
                            $order->payment_complete();
                            //$order->update_status('completed');
                            $this->add_notice("Votre paiement a &eacute;t&eacute valid&eacute; avec succ&eagrave;");
                            //wp_redirect($this->get_return_url($order));
                            die();
                        } elseif ($code == '623') {
                            $note = 'En attente de validation'.$commentaire;
                            $order->add_order_note($note);
                            $order->update_status('on-hold');
                            $this->log('Le paiement est en attente de validation du client');
                            $this->add_notice("Vous devez valider votre paiement avant qu'il soit pris en compte", "error");
                            //wp_redirect($this->get_return_url($order));
                            die();
                        }elseif ($code == '602') {
                            $note = 'Compte client insuffisant'.$commentaire;
                            $order->add_order_note($note);
                            $order->update_status('failed');
                            $this->log('Paiement echou&eacute; car le compte du client est insuffisant');
                            $this->add_notice('Le paiement a echou&eacute; car votre compte est insuffisant', 'error');
                            wp_redirect($error_url);
                            die();
                        }elseif ($code == '604') {
                            $note = 'Le code OTP est erron&eacute;'.$commentaire;
                            $order->add_order_note($note);
                            $order->update_status('failed');
                            $this->log('Paiement echou&eacute; car Le code OTP est erron&eacute;');
                            $this->add_notice('Le paiement a echou&eacute; car le code OTP est erron&eacute;', 'error');
                            //wp_redirect($error_url);
                            die();
                        }elseif ($code == '627') {
                            $note = 'Annulation volontairement de la transaction'.$commentaire;
                            $order->add_order_note($note);
                            $order->cancel_order();
                            $this->log('Paiement echou&eacute; car Annulation volontairement la transaction');
                            $this->add_notice('Le paiement a echou&eacute; car vous avez annulez le paiement', 'error');
                            //wp_redirect($error_url);
                            die();
                        }elseif($message == 'PAYMENT_FAILED') {
                            $note = 'Paiement echou&eacute'.$commentaire;
                            $order->add_order_note($note);
                            $order->update_status('failed');
                            $this->log('Paiement echou&eacute;. ');
                            $this->add_notice('Le paiement a echou&eacute; car une erreur est survenue', 'error');
                            //wp_redirect($error_url);
                            die();
                        }
                    }else{
                        $this->log('Erreur ! La commande a un statut inconnu: '.$order->status.', Id de la Transaction : '.$transaction_id.',Id de commande : '.$order->id);
                        wp_die(sprintf(__('Une erreur est survenue, veuillez contacter le responsable du site avec votre id de commande (%s).', 'cinetpay'), $order->id));
                    }
                }
            } catch (Exception $exception) {
                echo "Erreur :" . $exception->getMessage();

        }
	}

	private function is_new_order($order, $trs_id) {
		if ($order->status === 'pending') {
			return true;
		}
		if ($order->status === 'failed' || $order->status === 'cancelled') {
			return get_post_meta((int) $order->id, 'Transaction ID', true) !== $trs_id;
		}
		return false;
	}

	protected function log($msg) {
		if (!$this->debug) {
			return;
		}

		$this->logger->add('cinetpay', $msg);
	}

	protected function clear_notices() {
		global $woocommerce;

		if(function_exists('wc_clear_notices')) {
			wc_clear_notices();
		} else {
			$woocommerce->clear_messages();
		}
	}

	protected function add_notice($msg, $type='success') {
		global $woocommerce;

		if(function_exists('wc_add_notice')) {
			wc_add_notice($msg, $type);
		} else {
			if($type == 'error') {
				$woocommerce->add_error($msg);
			} else {
				$woocommerce->add_message($msg);
			}
		}
	}
    //Conversion de la devise
    public function convertPriceFull($amount_from, $currency_from, $currency_to)
    {
        $currency_from = strtoupper($currency_from);
        $amount_to = $amount_from;
        if ($currency_from == 'FCFA' || $currency_from == 'F CFA' || $currency_from == 'CFA') {
            $currency_from = 'XOF';
        }
        if ($currency_from != $currency_to) {
            $valueCurrency = $currency_from . "-" . $currency_to;
            $url = "https://api.cinetpay.com/new/index.php/v1/currency?q=" . $valueCurrency;
           
           // changement de methode
           $response= $this->callCinetpayWsMethod(null, $url, 'GET');

            if (!empty($response)) {
                $response = doubleval($response);
                if (is_double($response) && $response > 0) {
                    $exchange_rate = $response;
                }
            }
            if (empty($exchange_rate)) {
                throw new Exception("Error 222222222221");
            }
            $amount_to = ceil($amount_from * $exchange_rate);
        }
        return round($amount_to);
    }
    //Recherche de l'existence de la devise dans Cinetpay
    public function checkCurrency($countryCode,$devise)
    {
         /* Utilisation de la devise pour la concatener au pays. 
          * Utile pour les pays qui utilise plusieurs devise comme RDCongo(22-03-2022)*/   
        if ($devise == 'USD' && $countryCode == 'CD')
        {
            $concatDevise = 'USD';
        }
        else{
            $concatDevise = '';
        }
        //changement de methode
        $response = $this->callCinetpayWsMethod(null, 'https://new-api.cinetpay.ci/v2/countries/'.$countryCode.$concatDevise, 'GET');

        if(!empty($response))
        {
            $result = json_decode($response,true);
            
            if($result['data'][0]['currency'] && $result['data'][0]['is_payin_available']=='Y'){
                $test = $result['data'][0]['currency'];

                return $test;
            }
            
            
        }
        return null;
    }

    //function appelé dans le cas où l'admin ne veut pas convertir le montant dans la devise du pays du payeur
 	public function CurrencySupportCinetpay($currencyWc)
     { 
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://new-api.cinetpay.ci/v2/countries/',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
           CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
          echo $err;
          wp_die($err);die();
          //throw new Exception("Error :" . $err);
        } 
        
        if(!empty($response))
        {
            $result = json_decode($response,true);
            
            foreach ($result['data'] as $key => $value) {
                if($value['currency']==$currencyWc)
                {
                    return $value['currency'];
                }
            }
            return null;
            
        }
     }
     //Function de verifcation du multiple de 5
     function multipleFive($devise,$nbre)
     {
         switch ($devise) {
             case 'USD':
                 return $nbre;
                 break;
             
             default:
                    if(($nbre % 5) == 0)
                    {
                        return $nbre;
                    }
                    else{
                        do {
                            $nbre += 1; 
                            
                        } while (($nbre % 5) != 0);
                        return $nbre;
                    } 
                 break;
         }
    
         
     }
     public function callCinetpayWsMethod($params, $url, $method)
     {
       
         if (function_exists('curl_version')) {
             try {
                 $curl = curl_init();
                
                 curl_setopt_array($curl, array(
                     CURLOPT_URL => $url,
                     CURLOPT_RETURNTRANSFER => true,
                     CURLOPT_ENCODING => "",
                     CURLOPT_MAXREDIRS => 10,
                     CURLOPT_TIMEOUT => 45,
                     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                     CURLOPT_CUSTOMREQUEST => $method,
                     CURLOPT_POSTFIELDS => json_encode($params),
                     CURLOPT_SSL_VERIFYPEER => 0,
                 ));
                 $response = curl_exec($curl);
                 $err = curl_error($curl);
                 curl_close($curl);
                 if ($err) {
                     throw new Exception("Error :" . $err);
                 } else {
                     return $response;
                 }
             } catch (Exception $e) {
                 throw new Exception($e);
             }
         }  else {
             throw new Exception("Vous devez activer curl ou allow_url_fopen pour utiliser CinetPay");
         }
     }
     

}
